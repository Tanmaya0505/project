<?php
include("model/configuration.php");
include("view/welcome.html");
?>
